package com.raithanna.dairy.RaithannaDairy.models;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public class message {
    private String message;
}
