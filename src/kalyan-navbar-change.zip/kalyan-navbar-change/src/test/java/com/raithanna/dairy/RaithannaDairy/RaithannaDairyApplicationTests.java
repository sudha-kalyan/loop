package com.raithanna.dairy.RaithannaDairy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RaithannaDairyApplicationTests {

	@Test
	void contextLoads() {
	}

}
